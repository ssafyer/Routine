import { useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useEffect, useState } from 'react';

const NavBar = () => {
	const userId = useSelector((state) => {
		return state.user.value.userId;
	});
	const path = useLocation().pathname;
	const navigate = useNavigate();
	const [plus, setPlus] = useState(false);
	const [action, setAction] = useState(false);

	useEffect(() => {
		console.log(path);
	}, [path]);

	return (
		<>
		</>
	);
};
export default NavBar;
